#include "Principal.h"

Principal::Principal()
{
}

void Principal::menu()
{
    cout<<"Bienvenido al programa de letras"<<endl;
    int n = stoi(v.leer("Ingrese el tamaño del arreglo: "));
    Letras L=Letras(n);
    Validaciones v;
    int opc ;
    int* res;
    int pos;
    string buscada="", buscada2="";
    do
    {
        cout<<"1.- Llenar arreglo"<<endl;
        cout<<"2.- Mostrar arreglo"<<endl;
        cout<<"3.- buscar la cantidad de veces que aparece una letra"<<endl;
        cout<<"4.- buscar letra-"<<endl;
        cout<<"5.- reemplazar"<<endl;
        cout<<"6.- Retornar letra"<<endl;
        cout<<"7.- juego de palabras"<<endl;
        cout<<"8.- Salir"<<endl;
        opc = stoi(v.leer("Ingrese una opcion: "));
        switch(opc) 
        {
            case 1:
                cout<<"has escogido la opcion de llenar arreglo"<<endl;
                cout<<L.llenarArreglo()<<endl; 
                break;
            case 2:
                cout<<"has escogido la opcion de mostrar arreglo"<<endl;
                cout<<L.devolverDato()<<endl;
                break;
            case 3:
                cout<<"has escogido la opcion de buscar la cantidad de veces que aparece una letra"<<endl;
                buscada = v.leer("Ingrese la letra a buscar: ");
                cout<<"la cantidad de veces que aparece "<<buscada<<" es: "<<L.cantidadLetras(buscada)<<endl;
                break;
            case 4:
                cout<<"has escogido la opcion de buscar letra"<<endl;
                buscada2 = v.leer("Ingrese la letra a buscar: ");
                res = L.buscarPosicion(buscada2);
                pos = L.cantidadLetras(buscada2);
                cout<<"la letra "<<buscada2<<" se encuentra en las posiciones: ";
                if (pos == 0)
                {
                    cout<<"no se encuentra"<<endl;
                }
                else
                {
                    for (int i = 0; i < pos; i++)
                    {
                        cout<<res[i]<<" ";
                    }
                    cout<<endl;
                }
                break;
            case 5:
                cout<<"has escogido la opcion de reemplazar"<<endl;
                pos = stoi(v.leer("Ingrese la posicion a reemplazar: "));
                buscada = v.leer("Ingrese la letra a reemplazar: ");
                cout<<L.reemplazarLetra(pos,buscada)<<endl;
                break;
            case 6:
                cout<<"has escogido la opcion de retornar letra"<<endl;
                pos = stoi(v.leer("Ingrese la posicion a retornar: "));
                cout<<"la letra en la posicion "<<pos<<" es: "<<L.retornarLetra(pos)<<endl;
                break;
            case 7:
                cout<<"has escogido la opcion de juego de palabras"<<endl;
                L.juegoPalabras();
                break;
            case 8:
                cout<<"has escogido la opcion de salir"<<endl;
                L.cerrar();
                break;
            default:
                cout<<"Opcion no valida"<<endl;
                break;
        }
    }while (opc!=8);  
}