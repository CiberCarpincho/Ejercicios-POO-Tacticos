#include "Letras.h"

Letras::Letras()
{
    tam=0;
    arreglo=nullptr;
    palabras=nullptr;
    canPalabra=0;
}
Letras::~Letras()
{

}

void Letras::cerrar()
{
    delete[] arreglo;
    delete[] palabras;
}
Letras::Letras(int tam)
{
    this->tam=tam;
    palabras = new Palabra[canPalabra];
}
string Letras::llenarArreglo()
{
    srand(time(NULL));
    for(int i=0;i<tam;i++)
    {
        arreglo[i]=(rand()%26)+97;
    }
    return "Arreglo llenado re melo!!!!";
}
string Letras::devolverDato()
{
    string aux="Los datos son:  ";
    for(int i=0;i<tam;i++)
    {
        aux+=arreglo[i]+"\t";
    }
    return aux;
}

int Letras::cantidadLetras(string letra)
{
    int contador=0;
    for(int i=0;i<tam;i++)
    {
        if(arreglo[i]==letra)
        {
            contador++;
        }
    }
    return contador;
}
int* Letras::buscarPosicion(string let)
{
    int cantidad=cantidadLetras(let);
    int *resultado=new int[cantidad];
    if(cantidad==0)
    {   
        delete[] resultado;
        resultado= new int[1];
        resultado[0]=-1;
    }
    else
    {
        int j=0;
        for(int i=0;i<tam;i++)
        {
            if(arreglo[i]==let)
            {
                resultado[j]=i;
                j++;
            }
        }
    }
    return resultado;
}
string Letras::reemplazarLetra(int pos,string letra)
{
    if(pos>=0 && pos<tam)
    {
        arreglo[pos]=letra;
        return "se reemplazo la letra "+letra+" en la posicion "+to_string(pos);
    }
    else
    {
        return "Posicion invalida";
    }
}
string Letras::retornarLetra(int pos)
{
    if (pos>=0 && pos<tam)
    {
        return arreglo[pos];
    }
    else
    {
        return "no está esta mondá en la posición "+to_string(pos);
    }
}
void Letras::juegoPalabras()
{
    int canPalabras=0;
    do
    {
        canPalabras=stoi(v.leer("digite la cantidad de palabras que desea ingresar: "));
        if (canPalabras<=0 || canPalabras>13)
        {
            cout<<"La cantidad de palabras debe ser mayor a 0 y menor a 13"<<endl;
        }
    }while(canPalabras<=0 || canPalabras>10);
    palabras=new Palabra[canPalabras];
    string newArreglo="";
    for (int i=0;i<tam;i++)
    {
        newArreglo+=arreglo[i];
    }
    for(int i=0;i<canPalabras;i++)
    {
        string palabra=v.leer("Digite la palabra "+to_string(i+1)+": ");
        palabras[i]=Palabra(newArreglo,palabra);
    }
    cout<<"-------------------------------------------------"<<endl;
    cout<<"aqui empezo la monda: "<<endl;
    for(int i=0;i<canPalabras;i++)
    {
        cout<<palabras[i].calcPalabra()<<endl;
    }
    cout<<"-------------------------------------------------"<<endl;
    cout<<"aqui termino la monda: "<<endl;  

}