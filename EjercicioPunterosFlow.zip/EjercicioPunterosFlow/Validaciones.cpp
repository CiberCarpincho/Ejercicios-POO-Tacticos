#include "Validaciones.h"

Validaciones::Validaciones()
{
    
}

string Validaciones::leer(string cadena)
{     
    string aux="";
    do
    {
        cout<<cadena<<endl;
        getline(cin,aux);
    }while(aux=="");
    return aux;
}

