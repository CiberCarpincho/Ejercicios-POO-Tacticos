#ifndef PALABRA_H
#define PALABRA_H

#include <iostream>
using namespace std;
class Palabra
{
    private:
        string palabra;
        string universo;
    public:
        Palabra();
        Palabra(string universo,string);
        ~Palabra();
        string calcPalabra();
    protected:
};

#endif // PALABRA_H