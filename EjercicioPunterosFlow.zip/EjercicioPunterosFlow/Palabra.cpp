#include "Palabra.h"

Palabra::Palabra()
{
    palabra="";
}

Palabra::Palabra(string universo,string palabra)
{
    this->palabra=palabra;
    universo="";
}

/*cualquier comentario */
string Palabra::calcPalabra()
{
    int sisePuede [universo.size()]; //arreglo de contadores para saber cuantas veces se repite cada letra en la palabra
    int sisePuedeIdeal[universo.size()];// arreglo de contadores para saber cuantas letras se necesita para formar la palabra
    bool estanoque[palabra.size()]; //arreglo de booleanos para saber si la letra de la palabra se generó en el arreglo
    string universoFalso=""; //arreglo secundario el cual no se modificara.
    for (int p=0 ; p<palabra.size();p++) //inicializa el arreglo de booleanos
    {
        estanoque[p]=false;
    }
    for (int p=0; p<universo.size();p++)//inicializa los arreglos de contadores y el arreglo secundario
    {
        sisePuede[p]=0;
        sisePuedeIdeal[p]=0;
        universoFalso+=universo[p];
    }
    for (int i=0; i<palabra.size(); i++)//ciclo para recorrer la palabra
    {
        for(int e=0; e<universo.size();e++)
        {
            if(palabra[i]==universo[e])//compara si la letra de la palabra se encuentra en el arreglo
            {
                sisePuede[e]++; //incrementa el contador de la letra en el arreglo
                universo[e]=' '; //cambia la letra en el arreglo por un espacio
                estanoque[i]=true; //cambia el valor del arreglo de booleanos indicando que la letra si se generó.
            }
            if(palabra[i]==universoFalso[e])//compara si la letra de la palabra se encuentra en el arreglo secundario 
            {
                sisePuedeIdeal[e]++;//incrementa el contador de la letra en el arreglo secundario
            }
        }
    }
    for(int i=0;i<palabra.size();i++)//ciclo para verificar si la palabra se puede formar
        if (estanoque[i]==false)//si la letra de la palabra no se generó en el arreglo
            return "la palabra "+palabra+" no se puede formar ya que la letra "+palabra[i]+" no se generó en el arreglo.";
    for(int i=0; i<universo.size();i++)//ciclo para verificar si la palabra se puede formar
    {
        sisePuedeIdeal[i]-=sisePuede[i];//resta los contadores de las letras en el arreglo secundario con los contadores de las letras en el arreglo
        if (sisePuedeIdeal[i]>0)//si el contador de la letra en el arreglo secundario es mayor a 0 significa que faltan caracteres para formar la palabra.
        {
            return "No se puede generar la palabra "+palabra+" ya que falta "+to_string(sisePuedeIdeal[i])+" veces el caracter "+
            universo[i]+".";
        }
    }
    return "La palabra "+palabra+" se puede generar con un exito Brutaaaaaaaaal!!!."; //si no se cumple ninguna de las condiciones anteriores significa que la palabra se puede formar.
}
Palabra::~Palabra()
{
    //dtor
}
