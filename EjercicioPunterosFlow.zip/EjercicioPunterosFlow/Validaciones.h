#ifndef VALIDACIONES_H
#define VALIDACIONES_H

#include <iostream>
#include <string>

using namespace std;

class Validaciones
{
    public:
        Validaciones();
        string leer(string);

    private:

    protected:

};   
#endif // VALIDACIONES_H