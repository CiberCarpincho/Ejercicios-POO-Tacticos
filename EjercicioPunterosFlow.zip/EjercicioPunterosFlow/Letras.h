#ifndef LETRAS_H
#define LETRAS_H

#include "Validaciones.h"
#include "Palabra.h"
#include <time.h>


class Letras
{
    private:
        Validaciones v;
        int canPalabra;
        Palabra* palabras;
    public:
        Letras();
        Letras(int);
        ~Letras();
        string llenarArreglo();
        string devolverDato();
        int* buscarPosicion(string);
        string reemplazarLetra(int,string);
        int cantidadLetras(string);
        string retornarLetra(int);
        void juegoPalabras();
        void cerrar();
    protected:
        int tam;
        string *arreglo;
};


#endif // LETRAS_H