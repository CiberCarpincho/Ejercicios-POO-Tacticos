#include "Validaciones.h"
#include "Principal.h"
#include <clocale>

int main()
{   
    setlocale(LC_ALL, "es_ES.UTF-8");
    Principal p;
    p.menu();
    return 0;
}