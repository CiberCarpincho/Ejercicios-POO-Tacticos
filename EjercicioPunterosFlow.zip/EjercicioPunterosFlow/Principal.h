#ifndef PRINCIPAL_H
#define PRINCIPAL_H

#include "Validaciones.h"
#include "Letras.h"
class Principal
{
    public:
        Principal();
        void menu();
    private:
        Validaciones v;
    
    protected:

};
#endif // PRINCIPAL_H